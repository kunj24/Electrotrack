"use client"

import { useState } from "react"
import Link from "next/link"
import { ShoppingCart, User, Menu, X, Phone, Mail, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const cartItems = 3 // This would come from state management

  return (
    <header className="bg-white shadow-sm border-b">
      {/* Top bar with contact info */}
      <div className="bg-blue-600 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between items-center text-sm">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <Phone className="h-3 w-3" />
                <span>+91 9510886281</span>
              </div>
              <div className="flex items-center space-x-1">
                <Mail className="h-3 w-3" />
                <span>jayeshsavaliya3011@gmail.com</span>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <MapPin className="h-3 w-3" />
              <span>18-gala minibazar, matavadi circle, surat Gujarat India - 394107</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="bg-blue-600 text-white p-2 rounded-lg">
              <span className="font-bold text-xl">RE</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-blue-600">RADHIKA ELECTRONICS</h1>
              <p className="text-sm text-gray-600">Premium Electronics Store</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/dashboard" className="text-gray-700 hover:text-blue-600 font-medium">
              Products
            </Link>
            <Link href="/cart" className="relative">
              <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                <ShoppingCart className="h-4 w-4" />
                <span>Cart</span>
                {cartItems > 0 && (
                  <Badge variant="destructive" className="ml-1">
                    {cartItems}
                  </Badge>
                )}
              </Button>
            </Link>
            <Link href="/login">
              <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                <User className="h-4 w-4" />
                <span>Login</span>
              </Button>
            </Link>
          </nav>

          {/* Mobile menu button */}
          <Button
            variant="outline"
            size="sm"
            className="md:hidden bg-transparent"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t pt-4">
            <div className="flex flex-col space-y-3">
              <Link href="/dashboard" className="text-gray-700 hover:text-blue-600 font-medium">
                Products
              </Link>
              <Link href="/cart" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600">
                <ShoppingCart className="h-4 w-4" />
                <span>Cart ({cartItems})</span>
              </Link>
              <Link href="/login" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600">
                <User className="h-4 w-4" />
                <span>Login</span>
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
