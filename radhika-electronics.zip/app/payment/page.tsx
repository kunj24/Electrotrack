"use client"

import type React from "react"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { CreditCard, Smartphone, Building, Shield } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function PaymentPage() {
  const [paymentMethod, setPaymentMethod] = useState("upi")
  const [paymentData, setPaymentData] = useState({
    upiId: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    cardName: "",
    accountNumber: "",
    ifscCode: "",
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  const orderTotal = 67497 // This would come from cart/shipping data

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      toast({
        title: "Payment successful!",
        description: "Your order has been placed successfully. You will receive a confirmation email shortly.",
      })
      // Redirect to success page
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Complete Payment</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Payment Methods */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Choose Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                  {/* UPI Payment */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="upi" id="upi" />
                      <Label htmlFor="upi" className="flex-1 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <Smartphone className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium">UPI Payment</p>
                            <p className="text-sm text-gray-600">Pay using Google Pay, PhonePe, Paytm</p>
                          </div>
                        </div>
                      </Label>
                    </div>

                    {paymentMethod === "upi" && (
                      <div className="ml-6 space-y-4">
                        <div>
                          <Label htmlFor="upiId">UPI ID</Label>
                          <Input
                            id="upiId"
                            placeholder="yourname@paytm"
                            value={paymentData.upiId}
                            onChange={(e) => setPaymentData((prev) => ({ ...prev, upiId: e.target.value }))}
                          />
                        </div>
                        <div className="flex space-x-4">
                          <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                            <img src="/placeholder.svg?height=20&width=20" alt="Google Pay" className="w-5 h-5" />
                            <span>Google Pay</span>
                          </Button>
                          <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                            <img src="/placeholder.svg?height=20&width=20" alt="PhonePe" className="w-5 h-5" />
                            <span>PhonePe</span>
                          </Button>
                          <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                            <img src="/placeholder.svg?height=20&width=20" alt="Paytm" className="w-5 h-5" />
                            <span>Paytm</span>
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Credit/Debit Card */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="card" id="card" />
                      <Label htmlFor="card" className="flex-1 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <CreditCard className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium">Credit/Debit Card</p>
                            <p className="text-sm text-gray-600">Visa, Mastercard, RuPay</p>
                          </div>
                        </div>
                      </Label>
                    </div>

                    {paymentMethod === "card" && (
                      <div className="ml-6 space-y-4">
                        <div>
                          <Label htmlFor="cardNumber">Card Number</Label>
                          <Input
                            id="cardNumber"
                            placeholder="1234 5678 9012 3456"
                            value={paymentData.cardNumber}
                            onChange={(e) => setPaymentData((prev) => ({ ...prev, cardNumber: e.target.value }))}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiryDate">Expiry Date</Label>
                            <Input
                              id="expiryDate"
                              placeholder="MM/YY"
                              value={paymentData.expiryDate}
                              onChange={(e) => setPaymentData((prev) => ({ ...prev, expiryDate: e.target.value }))}
                            />
                          </div>
                          <div>
                            <Label htmlFor="cvv">CVV</Label>
                            <Input
                              id="cvv"
                              placeholder="123"
                              value={paymentData.cvv}
                              onChange={(e) => setPaymentData((prev) => ({ ...prev, cvv: e.target.value }))}
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="cardName">Cardholder Name</Label>
                          <Input
                            id="cardName"
                            placeholder="Name on card"
                            value={paymentData.cardName}
                            onChange={(e) => setPaymentData((prev) => ({ ...prev, cardName: e.target.value }))}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Net Banking */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="netbanking" id="netbanking" />
                      <Label htmlFor="netbanking" className="flex-1 cursor-pointer">
                        <div className="flex items-center space-x-3">
                          <Building className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium">Net Banking</p>
                            <p className="text-sm text-gray-600">All major banks supported</p>
                          </div>
                        </div>
                      </Label>
                    </div>

                    {paymentMethod === "netbanking" && (
                      <div className="ml-6 space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="accountNumber">Account Number</Label>
                            <Input
                              id="accountNumber"
                              placeholder="Account number"
                              value={paymentData.accountNumber}
                              onChange={(e) => setPaymentData((prev) => ({ ...prev, accountNumber: e.target.value }))}
                            />
                          </div>
                          <div>
                            <Label htmlFor="ifscCode">IFSC Code</Label>
                            <Input
                              id="ifscCode"
                              placeholder="IFSC code"
                              value={paymentData.ifscCode}
                              onChange={(e) => setPaymentData((prev) => ({ ...prev, ifscCode: e.target.value }))}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <Button variant="outline" size="sm">
                            SBI
                          </Button>
                          <Button variant="outline" size="sm">
                            HDFC
                          </Button>
                          <Button variant="outline" size="sm">
                            ICICI
                          </Button>
                          <Button variant="outline" size="sm">
                            Axis
                          </Button>
                          <Button variant="outline" size="sm">
                            PNB
                          </Button>
                          <Button variant="outline" size="sm">
                            Others
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </RadioGroup>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-blue-600" />
                    <p className="text-sm text-blue-800">Your payment information is secure and encrypted</p>
                  </div>
                </div>

                <form onSubmit={handlePayment} className="mt-6">
                  <Button type="submit" size="lg" className="w-full" disabled={isProcessing}>
                    {isProcessing ? "Processing Payment..." : `Pay ₹${orderTotal.toLocaleString()}`}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Payment Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>₹57,497</span>
                </div>

                <div className="flex justify-between">
                  <span>GST (18%)</span>
                  <span>₹10,349</span>
                </div>

                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>₹500</span>
                </div>

                <Separator />

                <div className="flex justify-between text-lg font-bold">
                  <span>Total Amount</span>
                  <span>₹{orderTotal.toLocaleString()}</span>
                </div>

                <div className="mt-4 p-3 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-800">✓ Secure payment gateway</p>
                  <p className="text-sm text-green-800">✓ 256-bit SSL encryption</p>
                  <p className="text-sm text-green-800">✓ PCI DSS compliant</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
