"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Download, FileText, Calendar } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Transaction {
  id: string
  date: string
  type: "sale" | "expense"
  description: string
  category: string
  amount: number
  paymentMethod: string
  status: "completed" | "pending" | "failed"
  customer?: string
}

const transactions: Transaction[] = [
  {
    id: "TXN001",
    date: "2024-01-15",
    type: "sale",
    description: 'Samsung 43" Smart TV',
    category: "TVs",
    amount: 32999,
    paymentMethod: "UPI",
    status: "completed",
    customer: "Rajesh Kumar",
  },
  {
    id: "TXN002",
    date: "2024-01-15",
    type: "expense",
    description: "Store Rent",
    category: "Operational",
    amount: 25000,
    paymentMethod: "Bank Transfer",
    status: "completed",
  },
  {
    id: "TXN003",
    date: "2024-01-14",
    type: "sale",
    description: "LG 1.5 Ton Split AC",
    category: "ACs",
    amount: 28999,
    paymentMethod: "COD",
    status: "completed",
    customer: "Priya Sharma",
  },
  {
    id: "TXN004",
    date: "2024-01-14",
    type: "sale",
    description: "Bajaj Ceiling Fan",
    category: "Fans",
    amount: 2499,
    paymentMethod: "Card",
    status: "pending",
    customer: "Amit Patel",
  },
  {
    id: "TXN005",
    date: "2024-01-13",
    type: "expense",
    description: "Electricity Bill",
    category: "Utilities",
    amount: 8500,
    paymentMethod: "Online",
    status: "completed",
  },
  {
    id: "TXN006",
    date: "2024-01-13",
    type: "sale",
    description: "iPhone 15 128GB",
    category: "Mobiles",
    amount: 79999,
    paymentMethod: "UPI",
    status: "completed",
    customer: "Neha Gupta",
  },
  {
    id: "TXN007",
    date: "2024-01-12",
    type: "sale",
    description: "Dell Inspiron Laptop",
    category: "Laptops",
    amount: 45999,
    paymentMethod: "Net Banking",
    status: "failed",
    customer: "Vikram Singh",
  },
  {
    id: "TXN008",
    date: "2024-01-12",
    type: "expense",
    description: "Product Purchase - TVs",
    category: "Inventory",
    amount: 150000,
    paymentMethod: "Bank Transfer",
    status: "completed",
  },
]

export default function TransactionsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("date")
  const { toast } = useToast()

  const filteredTransactions = transactions
    .filter((transaction) => {
      const matchesSearch =
        transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (transaction.customer && transaction.customer.toLowerCase().includes(searchTerm.toLowerCase()))

      const matchesType = filterType === "all" || transaction.type === filterType
      const matchesStatus = filterStatus === "all" || transaction.status === filterStatus

      return matchesSearch && matchesType && matchesStatus
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "amount-high":
          return b.amount - a.amount
        case "amount-low":
          return a.amount - b.amount
        case "date":
        default:
          return new Date(b.date).getTime() - new Date(a.date).getTime()
      }
    })

  const totalSales = transactions
    .filter((t) => t.type === "sale" && t.status === "completed")
    .reduce((sum, t) => sum + t.amount, 0)

  const totalExpenses = transactions
    .filter((t) => t.type === "expense" && t.status === "completed")
    .reduce((sum, t) => sum + t.amount, 0)

  const exportToCSV = () => {
    const csvContent = [
      ["ID", "Date", "Type", "Description", "Category", "Amount", "Payment Method", "Status", "Customer"],
      ...filteredTransactions.map((t) => [
        t.id,
        t.date,
        t.type,
        t.description,
        t.category,
        t.amount,
        t.paymentMethod,
        t.status,
        t.customer || "",
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "transactions.csv"
    a.click()

    toast({
      title: "Export successful!",
      description: "Transactions have been exported to CSV.",
    })
  }

  const exportToPDF = () => {
    toast({
      title: "PDF Export",
      description: "PDF export functionality will be implemented soon!",
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-100 text-red-800">Failed</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getTypeBadge = (type: string) => {
    return type === "sale" ? (
      <Badge className="bg-blue-100 text-blue-800">Sale</Badge>
    ) : (
      <Badge className="bg-orange-100 text-orange-800">Expense</Badge>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-blue-600">Transaction Management</h1>
              <p className="text-gray-600">Track all sales and expenses</p>
            </div>
            <div className="flex items-center space-x-2">
              <Button onClick={exportToCSV} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
              <Button onClick={exportToPDF} variant="outline" size="sm">
                <FileText className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">₹{totalSales.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Completed transactions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">₹{totalExpenses.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">All expenses</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">₹{(totalSales - totalExpenses).toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Sales minus expenses</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filters & Search</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search transactions, ID, or customer..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="sale">Sales Only</SelectItem>
                  <SelectItem value="expense">Expenses Only</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Latest First</SelectItem>
                  <SelectItem value="amount-high">Amount: High to Low</SelectItem>
                  <SelectItem value="amount-low">Amount: Low to High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Transactions Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Transactions ({filteredTransactions.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell className="font-medium">{transaction.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-3 w-3 text-gray-400" />
                          <span>{new Date(transaction.date).toLocaleDateString()}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getTypeBadge(transaction.type)}</TableCell>
                      <TableCell className="max-w-xs truncate">{transaction.description}</TableCell>
                      <TableCell>{transaction.category}</TableCell>
                      <TableCell>{transaction.customer || "-"}</TableCell>
                      <TableCell>{transaction.paymentMethod}</TableCell>
                      <TableCell
                        className={`font-bold ${transaction.type === "sale" ? "text-green-600" : "text-red-600"}`}
                      >
                        {transaction.type === "sale" ? "+" : "-"}₹{transaction.amount.toLocaleString()}
                      </TableCell>
                      <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {filteredTransactions.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500">No transactions found matching your criteria.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
